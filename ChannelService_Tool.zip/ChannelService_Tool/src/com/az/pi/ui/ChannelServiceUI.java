package com.az.pi.ui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import jxl.format.Border;

public class ChannelServiceUI {
	public String path;
	JLabel textfield = new JLabel();

	public void fileUpload() {
		JFrame.setDefaultLookAndFeelDecorated(false);
		JDialog.setDefaultLookAndFeelDecorated(false);
		JFrame frame = new JFrame("Communication Channel Reviewer");
		frame.setSize(800, 500);
		frame.setLocation(100, 100);
		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JRadioButton radio_bs = new JRadioButton("Business System Name");
		radio_bs.setLocation(20, 20);
		radio_bs.setActionCommand("BusinessSystem");
		JRadioButton radio_channelName = new JRadioButton("Single Channel Name");
		radio_channelName.setLocation(40, 20);
		radio_channelName.setActionCommand("ChannelName");
		JRadioButton radio_channels = new JRadioButton("List of Channels");
		radio_channels.setLocation(60, 20);
		radio_channels.setActionCommand("Channels");
		JPanel searchCriteriaPnl = new JPanel();
		searchCriteriaPnl.setLayout(new FlowLayout());
		searchCriteriaPnl.setSize(100, 200);
		TitledBorder  title = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black),"Select scenario");
		searchCriteriaPnl.setBorder(title);
		searchCriteriaPnl.add(radio_bs);
		searchCriteriaPnl.add(radio_channelName);
		searchCriteriaPnl.add(radio_channels);
		ButtonGroup radioGrorp = new ButtonGroup();
		radioGrorp.add(radio_bs);
		radioGrorp.add(radio_channelName);
		radioGrorp.add(radio_channels);
		//radio_bs.addActionListener((ActionListener) this);
		///radio_channelName.addActionListener((ActionListener)this);
		//radio_channels.addActionListener((ActionListener)this);
		
		
		
		
		/*JButton button = new JButton("Select File");

		button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent ae) {
				JFileChooser fileChooser = new JFileChooser();
				int returnValue = fileChooser.showOpenDialog(null);
				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					path = selectedFile.getAbsolutePath();
					textfield.setText(path);

					System.out.println(selectedFile.getName() + "   "
							+ selectedFile.getTotalSpace());
				}
			}
		});*/
		textfield.setText(path);
		System.out.println(path);
		textfield.setEnabled(true);
		frame.add(searchCriteriaPnl);
		frame.add(textfield);
		//frame.add(button);
		// frame.pack();
		frame.setVisible(true);

	}
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
	}
	
}
