package com.az.pi.beans;

import java.util.HashMap;


public class ChannelBean {
	private String channelName;
	private String componentName;
	private String party;
	private String direction;
	private String transportProtocal;
	private String tpVesrion;
	private String messageProtocal;
	private String mpVersion;
	private String adapterType;
	private HashMap<String,String> fieldsMap;
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getParty() {
		return party;
	}
	public void setParty(String party) {
		this.party = party;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getTransportProtocal() {
		return transportProtocal;
	}
	public void setTransportProtocal(String transportProtocal) {
		this.transportProtocal = transportProtocal;
	}
	public String getTpVesrion() {
		return tpVesrion;
	}
	public void setTpVesrion(String tpVesrion) {
		this.tpVesrion = tpVesrion;
	}
	public String getMessageProtocal() {
		return messageProtocal;
	}
	public void setMessageProtocal(String messageProtocal) {
		this.messageProtocal = messageProtocal;
	}
	public String getMpVersion() {
		return mpVersion;
	}
	public void setMpVersion(String mpVersion) {
		this.mpVersion = mpVersion;
	}
	public HashMap<String, String> getFieldsMap() {
		return fieldsMap;
	}
	public void setFieldsMap(HashMap<String, String> fieldsMap) {
		this.fieldsMap = fieldsMap;
	}
	public String getAdapterType() {
		return adapterType;
	}
	public void setAdapterType(String adapterType) {
		this.adapterType = adapterType;
	}

}
