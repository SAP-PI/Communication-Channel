package com.az.pi.test;

import java.awt.EventQueue;

import com.az.pi.ui.ChannelServiceUI;

public class ChannelServiceUTTest {
	public static void main(String[] args) {
		Runnable runner = new Runnable() {
		      public void run() {
		    	  new ChannelServiceUI().fileUpload();
		      }
	};
	EventQueue.invokeLater(runner);
	}

}
