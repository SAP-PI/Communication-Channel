package com.az.pi.test;

import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import com.az.pi.beans.ChannelBean;
import com.sap.xi.basis.CommunicationChannel;
import com.sap.xi.basis.CommunicationChannelID;
import com.sap.xi.basis.CommunicationChannelIn;
import com.sap.xi.basis.CommunicationChannelInService;
import com.sap.xi.basis.CommunicationChannelQueryIn;
import com.sap.xi.basis.CommunicationChannelQueryOut;
import com.sap.xi.basis.CommunicationChannelReadIn;
import com.sap.xi.basis.CommunicationChannelReadOut;
import com.sap.xi.basis.GenericProperty;
import com.sap.xi.basis.GenericPropertyTable;
import com.sap.xi.basis.GenericTableRow;
import com.sap.xi.basis.GenericTableRowTableCell;
import com.sap.xi.basis.ModuleProcess;
import com.sap.xi.basis.ParameterGroup;
import com.sap.xi.basis.ProcessStep;
import com.sap.xi.basis.RestrictedGenericProperty;
import com.sap.xi.basis.global.LONGDescription;


public class ChannelTest {
	public static void main(String[] args) {
		try{
		String po_devURL = ""
				+ "";
		String po_qaURL = "http://brsdhtcpod02:50000/CommunicationChannelInService/CommunicationChannelInImplBean?wsdl=binding";
		String po_prdURL = "http://brsdhtcpod02:50000/CommunicationChannelInService/CommunicationChannelInImplBean?wsdl=binding";
		String pi_userName = "";
		String pi_password = "";
		String po_userName = "";
		String po_password = "";
	
		 File inputFile =  new File("C:\\Users\\Mohanraj.sivakumar\\Documents\\Temp\\Tool_ChannelList.xls");
	     System.out.println("Reading input file....");
	     ChannelTest channelTest = new ChannelTest();
	     List<CommunicationChannelID> channelList1 = channelTest.readInputExcel(inputFile,"PRD");
	//     List<CommunicationChannelID> channelList2 = channelTest.readInputExcel(inputFile,"PRD");
	    // List<CommunicationChannelID> channelList1 = channelTest.readInputExcel(inputFile,"X8Q");
	     System.out.println("Fetching Channel detaisl....DEV");
	   
	CommunicationChannelInService service = new CommunicationChannelInService();
	CommunicationChannelIn channelPort=service.getCommunicationChannelInPort();
     BindingProvider prov1 = (BindingProvider) channelPort;
     prov1.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, po_prdURL);
     prov1.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, po_userName);
     prov1.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, po_password);
     
    ChannelTest test=new ChannelTest();
    System.out.println("PO details");
  // HashMap<String, ChannelBean> service1ChannelList=test.fetchChannelDetails(channelPort,channelList,componentID);
    HashMap<String, ChannelBean> service1ChannelList=test.fetchChannelDetails(channelPort,channelList1,"");
    System.out.println("Fetched details from Server PO");
    System.out.println("PI details");
    BindingProvider prov2 = (BindingProvider) channelPort;
    prov2.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, po_qaURL);
    prov2.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, pi_userName);
    prov2.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, pi_password);
    System.out.println("Logged into PO Server");
    
   
  //HashMap<String, ChannelBean> service2ChannelList=test.fetchChannelDetails(channelPort,channelList,componentID2);
 HashMap<String, ChannelBean> service2ChannelList=test.fetchChannelDetails(channelPort,channelList1,"");
    System.out.println("Fetched details from Server PO");
    
   test.writeResults(service1ChannelList,service2ChannelList);
    System.out.println("Comaparison is done.Please check the Results.");
    
		}
		catch(Exception e){
			e.printStackTrace();
		}
    
	}
	
	public HashMap<String, ChannelBean> fetchChannelDetails(CommunicationChannelIn channelPort, List<CommunicationChannelID> channelQueryReqList,String businessSystem){
		HashMap<String, ChannelBean> channelMap = new HashMap<String, ChannelBean>();
		try{
			
			CommunicationChannelQueryIn communicationChannelQueryRequest=new CommunicationChannelQueryIn();
			List<CommunicationChannelID> channelQueryList = new ArrayList<CommunicationChannelID>();
			if(!channelQueryReqList.isEmpty()){
				for(CommunicationChannelID channel:channelQueryReqList){
					if(!channel.getChannelID().isEmpty() && !"Channel".equalsIgnoreCase(channel.getChannelID())) {
					communicationChannelQueryRequest.setCommunicationChannelID(channel);
					
					CommunicationChannelQueryOut queryOut = channelPort.query(communicationChannelQueryRequest);
					
					List<CommunicationChannelID> queryList= queryOut.getCommunicationChannelID();
					
					if(queryList.size()==1){
						channelQueryList.add(queryList.get(0));
					}else{
						for(CommunicationChannelID channel1:queryList){
							channelQueryList.add(channel1);
						}
					}
				}}
			}else{
				CommunicationChannelID communicationChannelID = new CommunicationChannelID();	
				communicationChannelID.setChannelID("");
				communicationChannelID.setComponentID(businessSystem);
				communicationChannelID.setPartyID("");
				communicationChannelQueryRequest.setCommunicationChannelID(communicationChannelID);
				CommunicationChannelQueryOut queryOut = channelPort.query(communicationChannelQueryRequest);
				channelQueryList= queryOut.getCommunicationChannelID();
			}
			CommunicationChannelReadIn communicationChannelReadRequest = new CommunicationChannelReadIn();
			communicationChannelReadRequest.setCommunicationChannelID(channelQueryList);
			CommunicationChannelReadOut channelReadList = channelPort.read(communicationChannelReadRequest);
			List<CommunicationChannel> channelList=channelReadList.getCommunicationChannel();
			int x=1;
			for(CommunicationChannel channel:channelList){
				ChannelBean channelBean = new ChannelBean();
				String compoentName=channel.getCommunicationChannelID().getComponentID();
				String channelparty = channel.getCommunicationChannelID().getPartyID();
				String channleName=channel.getCommunicationChannelID().getChannelID();
				String adapterType=channel.getAdapterMetadata().getName();
				String direction = channel.getDirection().value();
				String transportProtocal=channel.getTransportProtocol();
				String transVersion = channel.getTransportProtocolVersion();
				String messageProtocal=channel.getMessageProtocol();
				String messageProtocalVersion=channel.getMessageProtocolVersion();			
				 channelBean.setChannelName(channleName);
				 channelBean.setComponentName(compoentName);
				 channelBean.setParty(channelparty);
				 channelBean.setDirection(direction);
				 channelBean.setTransportProtocal(transportProtocal);
				 channelBean.setTpVesrion(transVersion);
				 channelBean.setMessageProtocal(messageProtocal);
				 channelBean.setMpVersion(messageProtocalVersion);
				 channelBean.setAdapterType(adapterType);
				 HashMap<String,String> fieldsValue = new HashMap<String,String>();
				 fieldsValue.put("Party", channelparty);
				 fieldsValue.put("Component", compoentName);
				 fieldsValue.put("Adapter Type", adapterType);
				 fieldsValue.put("Direction", direction);
				 fieldsValue.put("TransportProtocal", transportProtocal);
				 fieldsValue.put("TransportProtocal Version", transVersion);
				 fieldsValue.put("MessageProtocal", messageProtocal);
				 fieldsValue.put("MessageProtocal Version", messageProtocalVersion);
				 fieldsValue.put("FolderPath", channel.getAdministrativeData().getFolderPathID());
				 x++;
				List<GenericProperty> adapterSpecificAttributes = channel.getAdapterSpecificAttribute();
				for(GenericProperty property:adapterSpecificAttributes){
					 fieldsValue.put(property.getName(), property.getValue());
					
				}
				List<GenericPropertyTable> adapterSpecificTableAttributes =channel.getAdapterSpecificTableAttribute();
				
				for(GenericPropertyTable propery:adapterSpecificTableAttributes){
					List<GenericTableRow> tableRow=propery.getValueTableRow();
					for(GenericTableRow row:tableRow){
						for(GenericTableRowTableCell cell:row.getValueTableCell()){
							 fieldsValue.put(cell.getColumnName(), cell.getValue());
						}
					}
					
				}
				for(LONGDescription desc:channel.getDescription()){
					//System.out.println(desc.getLanguageCode()+"--"+desc.getValue());
				}
				int j=1;
				ModuleProcess moduleProcess= channel.getModuleProcess();
				for(ParameterGroup parameter:moduleProcess.getParameterGroup()){
					fieldsValue.put("ModuleKey"+j,parameter.getParameterGroupID());
					for(RestrictedGenericProperty property:parameter.getParameter()){
						 fieldsValue.put(property.getName(), property.getValue());
						 x++;
					}	
					j++;
				}
				int i=1;
				for(ProcessStep step:moduleProcess.getProcessStep()){					
					 fieldsValue.put("ModuleName"+i,step.getModuleName());
					 fieldsValue.put("ModuleType"+i,step.getModuleType().value());					 
					 i++;
				}
				channelBean.setFieldsMap(fieldsValue);
				channelMap.put(channleName, channelBean);
			}
			return channelMap;
			}catch(Exception e){
				e.printStackTrace();
			}
		return channelMap;
	}
		
	public void writeResults(HashMap<String, ChannelBean> service1ChannelList,HashMap<String, ChannelBean> service2ChannelList) {
		try{
			SimpleDateFormat format = new SimpleDateFormat("ddMMyyyyHHmmss");
		File exlFile= new File("D:\\Tool_ChannelService_sw\\ChannelReviewResults_"+format.format(new Date())+".xls");
		WritableWorkbook writableWorkbook = Workbook
				.createWorkbook(exlFile);
		WritableSheet writableSheet = writableWorkbook.createSheet(
				"Channel Details", 0);
		
		WritableFont wfontStatus = new WritableFont(WritableFont.createFont("Arial"), WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
		WritableCellFormat headerFormat = new WritableCellFormat(wfontStatus);
		 headerFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN, jxl.format.Colour.AUTOMATIC);
		 headerFormat.setBackground(Colour.GRAY_25);
		 headerFormat.setShrinkToFit(false);
		 writableSheet.addCell(new Label(0, 0, "ChannelName",headerFormat));
		 writableSheet.addCell(new Label(1, 0, "FieldName",headerFormat));
		 writableSheet.addCell(new Label(2, 0, "PO_FieldValue",headerFormat));	
		 writableSheet.addCell(new Label(3, 0, "PI_FieldValue",headerFormat));
		Set<String> keys=service1ChannelList.keySet();
		Iterator<String> keyIterator = keys.iterator();
		List<String> notFoundChannelList = new ArrayList<String>();
		int x=1;
		while(keyIterator.hasNext()){
			String channleName = keyIterator.next();
			ChannelBean service1ChannelBean = service1ChannelList.get(channleName);
			String compoentName=service1ChannelBean.getComponentName();
			String channelparty = service1ChannelBean.getParty();
			String channle=service1ChannelBean.getChannelName();
			String adapterType=service1ChannelBean.getAdapterType();
			String direction =service1ChannelBean.getDirection();
			String transportProtocal=service1ChannelBean.getTransportProtocal();
			String transVersion = service1ChannelBean.getTpVesrion();
			String messageProtocal=service1ChannelBean.getMessageProtocal();
			String messageProtocalVersion=service1ChannelBean.getMpVersion();
			HashMap<String,String> service1attributes = service1ChannelBean.getFieldsMap();
			HashMap<String,String> service2attributes = new HashMap<String,String>();			
			if(service2ChannelList.containsKey(channleName)){
				ChannelBean service2ChannelBean = service2ChannelList.get(channleName);
				service2attributes =service2ChannelBean.getFieldsMap();
				Set<String> fieldKeys = service1attributes.keySet();
				Iterator<String> fieldNames = fieldKeys.iterator();
				while(fieldNames.hasNext()){
					String field = fieldNames.next();
					WritableCellFormat cellFormat = compareValues(service1attributes.get(field), service2attributes.get(field));
					writableSheet.addCell(new Label(0, x, channle,cellFormat));
					writableSheet.addCell(new Label(1, x, field,cellFormat));
					writableSheet.addCell(new Label(2, x, service1attributes.get(field),cellFormat));
					writableSheet.addCell(new Label(3, x, service2attributes.get(field),cellFormat));
					 x++;
				}
			}else{
				notFoundChannelList.add(channleName);
			}
			
		}
		WritableSheet writableSheetNotFound = writableWorkbook.createSheet(
				"Not Found Channels", 1);
		int y=1;
		writableSheetNotFound.addCell(new Label(0, 0, "ChannelName"));
		for(String channelName:notFoundChannelList){
			writableSheetNotFound.addCell(new Label(0, y, channelName));
			y++;
		}
		writableWorkbook.write();
		writableWorkbook.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
	public WritableCellFormat compareValues(String service1Value,String service2Value){
		 WritableFont wfontStatus = new WritableFont(WritableFont.createFont("Arial"), WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
		   WritableCellFormat fCellstatus = new WritableCellFormat(wfontStatus);
	
		try{
		Colour backgroundColour = Colour.WHITE;
		if((service1Value!=null&&service2Value==null)||(service1Value==null&&service2Value!=null)){
			backgroundColour=Colour.RED;
		}else if(!service1Value.equals(service2Value)){
			backgroundColour=Colour.YELLOW;
		}else if(service1Value.equals(service2Value)){
			//backgroundColour=Colour.DARK_GREEN;
		}else{
			backgroundColour = Colour.WHITE;
		}
		
	    fCellstatus.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN, jxl.format.Colour.AUTOMATIC);
	    fCellstatus.setBackground(backgroundColour);
		}catch(Exception e){
			e.printStackTrace();
		}
	    return fCellstatus;
	}
	public List<CommunicationChannelID> readInputExcel(File exlFile,String sheetName){
		 List<CommunicationChannelID> communicationChannelIDs = new ArrayList<CommunicationChannelID>();
		 try{
		
			Workbook workbook = Workbook.getWorkbook(exlFile);
			String[] sheetNames = workbook.getSheetNames();
			Sheet sheet=null;
			for(int i=0;i<sheetNames.length;i++){
				System.out.println(sheetNames[i]);
				if(sheetNames[i].equalsIgnoreCase(sheetName)){
					sheet = workbook.getSheet(sheetNames[i]);
				}
			}
				
				int rows = sheet.getRows();			
				int columns = sheet.getColumns();
				System.out.println(rows+"  "+columns);
				for(int j=0;j<rows;j++){
					CommunicationChannelID channel = new CommunicationChannelID();
					//channel.setPartyID(sheet.getCell(0,j).getContents());
					channel.setPartyID("");
					channel.setComponentID(sheet.getCell(0,j).getContents());
					//channel.setComponentID("");
				//	channel.setChannelID(sheet.getCell(2,j).getContents());
					channel.setChannelID(sheet.getCell(1,j).getContents());
					communicationChannelIDs.add(channel);
					/*System.out.println();
					for(int k=0;k<columns;k++){
						System.out.print(" ");
						System.out.print(sheet.getCell(k,j).getContents());
					}*/
				}
						
			
		 }
			catch(Exception e){
				
			}
		 return communicationChannelIDs;
	}
}
