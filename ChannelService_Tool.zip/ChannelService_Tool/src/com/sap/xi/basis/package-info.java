@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/BASIS")
package com.sap.xi.basis;
