@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/BASIS/Global")
package com.sap.xi.basis.global;
